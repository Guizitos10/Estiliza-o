import React, {useState} from 'react';
import styled from 'styled-components';

const Card = styled.article`
  background:${props=>props.theme.surface};
  border-radius:${props=>props.theme.radius};
  box-shadow:${props=>props.theme.shadow};
  transition:transform ${'${'}props=>props.theme.transition};
  overflow:hidden;
  &:hover{transform:translateY(-6px)}
  &:focus{outline:3px solid rgba(37,99,235,0.18);outline-offset:2px}
`;
const Img = styled.div`width:100%;padding-top:100%;background:linear-gradient(135deg,#f1f5f9,#eef2ff)`;
const Body = styled.div`padding:12px;`;
export default function ProductCard({product}){
  const [loading,setLoading]=useState(false);
  const [added,setAdded]=useState(false);
  function add(){ setLoading(true); setTimeout(()=>{ setLoading(false); setAdded(true); },800); }
  return (
    <Card tabIndex="0" role="listitem" aria-labelledby={`title-${product.id}`}>
      {loading ? <div style={{paddingTop:'100%'}} aria-hidden="true" className="skeleton" /> : <Img aria-hidden="true" loading="lazy" />}
      <Body>
        <h3 id={`title-${product.id}`} style={{lineHeight:1.2,height:'2.4em',overflow:'hidden',display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical'}}>{product.title}</h3>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:8}}>
          <div style={{fontWeight:700}}>{product.price}</div>
          <div aria-label={`Rating ${product.rating}`}>{"★".repeat(Math.round(product.rating))}</div>
        </div>
        <div style={{marginTop:8,display:'flex',gap:8}}>
          <button onClick={add} disabled={loading||added} aria-pressed={added} style={{padding:'8px 12px',borderRadius:10}}> {added ? 'Adicionado' : 'Adicionar'}</button>
          <button style={{padding:'8px 12px',borderRadius:10,border:'1px solid rgba(0,0,0,0.08)'}}>⋯</button>
        </div>
      </Body>
    </Card>
  );
}
