import React from 'react';
import styled from 'styled-components';
const Wrap = styled.header`position:fixed;top:0;left:0;right:0;background:rgba(0,0,0,0.04);backdrop-filter:blur(6px);padding:12px 16px;z-index:40;`;
const Inner = styled.div`max-width:1100px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;`;
const Btn = styled.button`padding:6px 8px;border-radius:8px;`;
export default function Navbar({themeName,setThemeName}){
  return (
    <Wrap role="banner">
      <Inner>
        <div tabIndex="0">Brand</div>
        <div style={{display:'flex',gap:12,alignItems:'center'}}>
          <Btn aria-label="Toggle theme" onClick={()=>setThemeName(themeName==='dark'?'light':'dark')}>🌓</Btn>
          <div tabIndex="0" aria-label="Cart">🛒<span style={{background:'#2563eb',color:'#fff',padding:'2px 6px',borderRadius:10,marginLeft:6}}>3</span></div>
        </div>
      </Inner>
    </Wrap>
  );
}
