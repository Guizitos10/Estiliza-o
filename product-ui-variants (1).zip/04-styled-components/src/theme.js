export const light = {
  bg:'#ffffff', surface:'#f8f9fa', text:'#111827', muted:'#6b7280', primary:'#2563eb',
  radius:'12px', shadow:'0 6px 18px rgba(16,24,40,0.08)', transition:'200ms'
};
export const dark = {
  bg:'#0b1220', surface:'#0f1724', text:'#e6eef8', muted:'#9aa8bf', primary:'#60a5fa',
  radius:'12px', shadow:'0 10px 30px rgba(2,6,23,0.6)', transition:'200ms'
};
