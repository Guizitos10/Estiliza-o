import React, {useEffect, useState} from 'react';
import { ThemeProvider, createGlobalStyle } from 'styled-components';
import { light, dark } from './theme';
import Navbar from './components/Navbar.jsx';
import ProductCard from './components/ProductCard.jsx';
import { PRODUCTS } from './data/products.js';

const Global = createGlobalStyle`
  *{box-sizing:border-box}
  body{margin:0;font-family:Inter,system-ui; background:${'${'}props=>props.theme.bg}; color:${'${'}props=>props.theme.text}; -webkit-font-smoothing:antialiased;}
`;

export default function App(){
  const [themeName,setThemeName] = useState(localStorage.getItem('theme') || 'light');
  useEffect(()=>{ localStorage.setItem('theme', themeName); },[themeName]);
  const theme = themeName === 'dark' ? dark : light;
  return (
    <ThemeProvider theme={theme}>
      <Global />
      <Navbar themeName={themeName} setThemeName={setThemeName} />
      <main style={{maxWidth:1100, margin:'84px auto', padding:20}}>
        <section style={{display:'grid',gap:16, gridTemplateColumns:'repeat(1,1fr)'}} aria-live="polite">
          {PRODUCTS.map(p=> <ProductCard key={p.id} product={p} />)}
        </section>
      </main>
    </ThemeProvider>
  );
}
