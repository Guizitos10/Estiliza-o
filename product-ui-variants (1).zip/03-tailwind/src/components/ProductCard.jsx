import React, {useState} from 'react';
import Skeleton from './Skeleton.jsx';

export default function ProductCard({product}){
  const [loading,setLoading] = useState(false);
  const [added,setAdded] = useState(false);
  function handleAdd(){ setLoading(true); setTimeout(()=>{ setLoading(false); setAdded(true); }, 800); }

  return (
    <article className="bg-white dark:bg-slate-800 rounded-lg shadow transition-transform hover:-translate-y-2 focus:outline focus:outline-4 focus:outline-primary p-3" tabIndex="0" role="listitem" aria-labelledby={`title-${product.id}`}>
      <div className="relative">
        {loading ? <Skeleton /> : <div className="w-full aspect-square bg-gray-100 dark:bg-slate-700 rounded-md" loading="lazy" />}
        <span className={`absolute left-2 top-2 rounded-md px-2 py-1 text-xs ${product.tag==='Promo'?'bg-yellow-200':'bg-green-200'}`}>{product.tag}</span>
      </div>
      <h3 id={`title-${product.id}`} className="mt-3 font-semibold text-sm line-clamp-2">{product.title}</h3>
      <div className="mt-2 flex items-center justify-between font-bold">{product.price}<div aria-label={`Rating ${product.rating}`}>{"★".repeat(Math.round(product.rating))}</div></div>
      <div className="mt-3 flex gap-2">
        <button onClick={handleAdd} disabled={loading||added} className="px-3 py-2 rounded-md bg-primary text-white"> {added ? 'Adicionado' : 'Adicionar'}</button>
        <button className="px-3 py-2 rounded-md border">⋯</button>
      </div>
    </article>
  );
}
