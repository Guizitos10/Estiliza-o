import React from 'react';
export default function Skeleton(){ return <div className="w-full aspect-square skeleton" aria-hidden="true"></div>; }
