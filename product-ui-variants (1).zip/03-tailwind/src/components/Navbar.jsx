import React from 'react';
export default function Navbar({theme,setTheme}){
  return (
    <header className="fixed top-0 left-0 right-0 bg-white/60 dark:bg-slate-900/60 backdrop-blur border-b z-40">
      <div className="max-w-6xl mx-auto flex items-center justify-between p-3">
        <div className="font-bold" tabIndex="0">Brand</div>
        <div className="flex items-center gap-3">
          <button aria-label="Toggle theme" onClick={()=>setTheme(theme==='dark'?'light':'dark')} className="px-3 py-1 rounded-md">🌓</button>
          <div className="relative" tabIndex="0" aria-label="Cart">🛒 <span className="absolute -top-2 -right-2 bg-primary text-white text-xs px-2 rounded-full">3</span></div>
        </div>
      </div>
    </header>
  );
}
