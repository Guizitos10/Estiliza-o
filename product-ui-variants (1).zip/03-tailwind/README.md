# Tailwind CSS implementation

This folder contains a small React app implementing the product grid UI using **Tailwind CSS**.

Features:
- Navbar (fixed) with logo, theme toggle (persistent), cart badge.
- Responsive grid breakpoints exactly:
  - ≤480px: 1 column
  - 481–768px: 2 columns
  - 769–1024px: 3 columns
  - ≥1025px: 4 columns
- Product card with 1:1 image placeholder, 2-line ellipsis title, price, rating, tag and Add button (solid/outline/ghost).
- Hover elevation, focus ring, disabled/loading states with skeleton (no layout shift).
- Dark mode persisted in localStorage.
- Accessibility: keyboard navigation, aria-* attributes, focus visible.
- Animation transitions 150–250ms.

Quick start (requires Node.js):
1. cd into this folder
2. npm install
3. npm run dev
