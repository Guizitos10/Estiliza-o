module.exports = {
  content: ["./index.html","./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: { primary: '#2563eb' },
      borderRadius: { 'lg': '12px' }
    },
    screens: {
      'sm':'481px',
      'md':'769px',
      'lg':'1025px'
    }
  },
  darkMode: 'class'
}
