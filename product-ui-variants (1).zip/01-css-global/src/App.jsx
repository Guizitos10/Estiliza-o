import React, {useEffect, useState} from 'react';
import { PRODUCTS } from './data/products.js';
import Navbar from './components/Navbar.jsx';
import ProductCard from './components/ProductCard.jsx';

export default function App(){
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  useEffect(()=>{ document.documentElement.setAttribute('data-theme', theme); localStorage.setItem('theme', theme); },[theme]);
  return (
    <div className="app">
      <Navbar theme={theme} setTheme={setTheme} />
      <main className="container" aria-live="polite">
        <section className="grid" role="list">
          {PRODUCTS.map(p=> <ProductCard key={p.id} product={p} />)}
        </section>
      </main>
    </div>
  );
}
