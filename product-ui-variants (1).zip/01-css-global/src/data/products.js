export const PRODUCTS = [
  { id: 1, title: "Camiseta Básica Unissex - Algodão Premium", price: "R$ 79,90", rating: 4.5, tag: "Novo", img: "" },
  { id: 2, title: "Tênis Running Leve - Amortecimento", price: "R$ 249,90", rating: 4.8, tag: "Promo", img: "" },
  { id: 3, title: "Mochila Urbana 20L - Resistente à água", price: "R$ 199,90", rating: 4.3, tag: "Novo", img: "" },
  { id: 4, title: "Relógio Minimalista - Aço Inoxidável", price: "R$ 399,90", rating: 4.7, tag: "Promo", img: "" },
  { id: 5, title: "Óculos de Sol UV400 - Estilo Clássico", price: "R$ 129,90", rating: 4.2, tag: "Novo", img: "" },
  { id: 6, title: "Jaqueta Windbreaker - Compacta", price: "R$ 299,90", rating: 4.6, tag: "Promo", img: "" }
];
