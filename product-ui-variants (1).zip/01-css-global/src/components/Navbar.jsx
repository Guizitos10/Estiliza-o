import React from 'react';
export default function Navbar({theme,setTheme}){
  return (
    <header className="navbar" role="banner">
      <div className="nav-inner">
        <div className="logo" tabIndex="0">Brand</div>
        <div className="controls">
          <button aria-pressed={theme==='dark'} aria-label="Toggle theme" onClick={()=>setTheme(theme==='dark'?'light':'dark')} className="btn small">🌓</button>
          <div className="cart" aria-label="Cart" tabIndex="0">🛒<span className="badge" aria-hidden="true">3</span></div>
        </div>
      </div>
    </header>
  );
}
