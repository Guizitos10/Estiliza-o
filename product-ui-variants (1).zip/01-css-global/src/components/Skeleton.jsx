import React from 'react';
export default function Skeleton({ratio='1/1'}) {
  const [w,h] = ratio.split('/');
  return <div className="skeleton" style={{paddingTop: (parseFloat(h)/parseFloat(w))*100 + '%'}} aria-hidden="true"></div>;
}
