import React from 'react';
export default function Button({children,variant='solid',...rest}){
  return (
    <button className={`btn ${variant}`} {...rest}>
      {children}
    </button>
  );
}
