import React, {useState} from 'react';
import Button from './Button.jsx';
import Skeleton from './Skeleton.jsx';

export default function ProductCard({product}){
  const [loading,setLoading] = useState(false);
  const [added,setAdded] = useState(false);
  function handleAdd(){ setLoading(true); setTimeout(()=>{ setLoading(false); setAdded(true); }, 800); }

  return (
    <article className="card" role="listitem" tabIndex="0" aria-labelledby={`title-${product.id}`}>
      <div className="media">
        {loading ? <Skeleton ratio="1/1" /> : <div className="img" aria-hidden="true" loading="lazy"></div>}
        <span className={`tag ${product.tag==='Promo'?'promo':''}`} aria-hidden="true">{product.tag}</span>
      </div>
      <div className="body">
        <h3 id={`title-${product.id}`} className="title" title={product.title}>{product.title}</h3>
        <div className="meta">
          <div className="price">{product.price}</div>
          <div className="rating" aria-label={`Rating ${product.rating} out of 5`}>{"★".repeat(Math.round(product.rating))}</div>
        </div>
        <div className="actions">
          <Button variant="solid" onClick={handleAdd} disabled={loading || added} aria-pressed={added}>{added ? 'Adicionado' : 'Adicionar'}</Button>
          <Button variant="outline" aria-label="Mais opções">⋯</Button>
        </div>
      </div>
    </article>
  );
}
