import React from 'react';
import styles from './Navbar.module.css';
export default function Navbar({theme,setTheme}){
  return (
    <header className={styles.navbar} role="banner">
      <div className={styles.navInner}>
        <div className={styles.logo} tabIndex="0">Brand</div>
        <div className={styles.controls}>
          <button aria-pressed={theme==='dark'} aria-label="Toggle theme" onClick={()=>setTheme(theme==='dark'?'light':'dark')} className={styles.btn_small}>🌓</button>
          <div className={styles.cart} aria-label="Cart" tabIndex="0">🛒<span className={styles.badge} aria-hidden="true">3</span></div>
        </div>
      </div>
    </header>
  );
}
