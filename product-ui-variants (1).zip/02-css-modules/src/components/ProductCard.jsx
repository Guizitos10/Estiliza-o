import React, {useState} from 'react';
import Button from './Button.jsx';
import styles from './ProductCard.module.css';
import Skeleton from './Skeleton.jsx';

export default function ProductCard({product}){
  const [loading,setLoading] = useState(false);
  const [added,setAdded] = useState(false);
  function handleAdd(){ setLoading(true); setTimeout(()=>{ setLoading(false); setAdded(true); }, 800); }

  return (
    <article className={styles.card} role="listitem" tabIndex="0" aria-labelledby={`title-${product.id}`}>
      <div className={styles.media}>
        {loading ? <Skeleton ratio="1/1" /> : <div className={styles.img} aria-hidden="true" loading="lazy"></div>}
        <span className={styles.tag + ' ' + (product.tag==='Promo'?styles.promo:'')}} aria-hidden="true">{product.tag}</span>
      </div>
      <div className={styles.body}>
        <h3 id={`title-${product.id}`} className={styles.title} title={product.title}>{product.title}</h3>
        <div className={styles.meta}>
          <div className={styles.price}>{product.price}</div>
          <div className={styles.rating} aria-label={`Rating ${product.rating} out of 5`}>{"★".repeat(Math.round(product.rating))}</div>
        </div>
        <div className={styles.actions}>
          <Button variant="solid" onClick={handleAdd} disabled={loading || added} aria-pressed={added}>{added ? 'Adicionado' : 'Adicionar'}</Button>
          <Button variant="outline" aria-label="Mais opções">⋯</Button>
        </div>
      </div>
    </article>
  );
}
